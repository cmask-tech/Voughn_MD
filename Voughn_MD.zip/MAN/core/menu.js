// core/menu.js
const database = require('./database');
const { colorful } = require('./utils');

class MenuManager {
    constructor() {
        this.categories = {
            owner: {
                title: '👑 OWNER',
                description: 'Bot owner only commands',
                commands: []
            },
            group: {
                title: '👥 GROUP', 
                description: 'Group management commands',
                commands: []
            },
            general: {
                title: '🔧 GENERAL',
                description: 'General purpose commands',
                commands: []
            },
            fun: {
                title: '🎮 FUN',
                description: 'Entertainment and games',
                commands: []
            },
            tools: {
                title: '🛠️ TOOL',
                description: 'Utility and tool commands',
                commands: []
            },
            media: {
                title: '📷 MEDIA',
                description: 'Image, video, and audio commands',
                commands: []
            },
            download: {
                title: '📥 DOWNLOAD',
                description: 'Download from various platforms',
                commands: []
            },
            search: {
                title: '🔍 SEARCH',
                description: 'Search information online',
                commands: []
            },
            ai: {
                title: '🤖 AI',
                description: 'Artificial intelligence commands',
                commands: []
            },
            nsfw: {
                title: '🔞 NSFW',
                description: 'Adult content commands (if enabled)',
                commands: []
            }
        };
    }

    // Register commands to categories
    registerCommand(category, name, description, options = {}) {
        if (!this.categories[category]) {
            colorful.warning(`Category ${category} not found!`);
            return;
        }
        
        this.categories[category].commands.push({
            name,
            description,
            ownerOnly: options.ownerOnly || false,
            groupOnly: options.groupOnly || false,
            requiresAdmin: options.requiresAdmin || false
        });
    }

    // Generate menu text
    async generateMenu(prefix, userJid = null) {
        const settings = await database.getBotSettings();
        const isOwner = userJid ? await database.isOwner(userJid) : false;
        const isSudo = userJid ? await database.isSudo(userJid) : false;
        const mode = settings.mode || 'public';

        let menuText = `*╭───❂* 𝗕𝗢𝗧-𝗜𝗡𝗙𝗢 *❂───❂*\n`;
        menuText += `╏✺╭───────────❂*\n`;
        menuText += `┋⍟┃🤖 *VOUGHN_MD*\n`;
        menuText += `┋⍟┃ *ADVANCED WHATSAPP BOT*\n`;
        menuText += `┋⍟┃\n`;
        menuText += `┋⍟┃ ⚙️  *BOT CONF'S*\n`;
        menuText += `┋⍟┃ *Prefix:* [ *${prefix}* ]\n`;
        menuText += `┋⍟┃ *Mode:* ${mode.toUpperCase()}\n`;
        menuText += `┋⍟┃ *Owner:* ${isOwner ? '✅ Yes' : 'Not owner'}\n`;
        menuText += `┋⍟┃ *Sudo:* ${isSudo ? '✅ Yes' : 'Not sudo'}\n`;
        menuText += `┋⍟┃ *Commands:* ${this.getTotalCommands()}\n`;
        menuText += `*╰─❂✧voughMD-𝑩𝒐𝒕✧❂───❂*\n\n\n\n`;

        // Add categories with commands
            /// Add categories with commands
        for (const [categoryKey, category] of Object.entries(this.categories)) {
            if (category.commands.length === 0) continue;

            let categoryText = `${category.title}\n`;
            categoryText += `*✺╭───────────❂*\n`;

            let visibleCommands = 0;
            
            for (const cmd of category.commands) {
                // Check permissions
                if (cmd.ownerOnly && !isOwner) continue;
                if (mode === 'private' && !isOwner && !isSudo && !cmd.ownerOnly) continue;
                
                visibleCommands++;
                
                let commandLine = `┋⍟ ${prefix}${cmd.name}`;
                if (cmd.ownerOnly) commandLine += ` `;
                if (cmd.groupOnly) commandLine += ` `;
                if (cmd.requiresAdmin) commandLine += ` `;
                commandLine += `\n`;
                
                categoryText += commandLine;
            }

            // Only show category if it has visible commands OR if it's owner category and user is owner
            if (visibleCommands > 0 || (categoryKey === 'owner' && isOwner)) {
                categoryText += `╰── ❂───❂ ❂───❂\n\n`;
                menuText += categoryText;
            }
        }
                // Add footer
        menuText += `📖 *USER GUIDE*\n`;
        menuText += `╰─| Use ${prefix}help <command> for help\n\n`;

        menuText += `┋⍟ 🔗 *BOT INFO*\n`;
        menuText += `╰─|🪀️ Version: 2.0.0 | \nBy: Voughn || Cmask`;

        return menuText;
    }

    // Get help for specific command
    async generateCommandHelp(prefix, commandName, userJid = null) {
        // Find the command in any category
        for (const [categoryKey, category] of Object.entries(this.categories)) {
            const command = category.commands.find(cmd => cmd.name === commandName);
            if (command) {
                const isOwner = userJid ? await database.isOwner(userJid) : false;
                
                // Check permissions
                if (command.ownerOnly && !isOwner) {
                    return `❌ You don't have permission to view help for ${prefix}${commandName}`;
                }

                let helpText = `🔍 *COMMAND HELP: ${prefix}${commandName}*\n\n`;
                helpText += `📝 *Description:*\n${command.description}\n\n`;
                
                helpText += `🏷️  *Category:*\n${category.title}\n\n`;
                
                helpText += `⚙️  *Permissions:*\n`;
                helpText += `┋⍟┃ Owner Only: ${command.ownerOnly ? '✅ Yes' : '❌ No'}\n`;
                helpText += `┋⍟┃ Group Only: ${command.groupOnly ? '✅ Yes' : '❌ No'}\n`;
                helpText += `╰─ Admin Required: ${command.requiresAdmin ? '✅ Yes' : '❌ No'}\n\n`;

                helpText += `💡 *Usage:*\n${prefix}${commandName}`;
                
                // Add example if available
                if (command.example) {
                    helpText += `\n\n📚 *Example:*\n${command.example}`;
                }

                return helpText;
            }
        }
        
        return `❌ Command "${commandName}" not found. Use ${prefix}menu to see all commands.`;
    }

    // Get total number of commands
    getTotalCommands() {
        let total = 0;
        for (const category of Object.values(this.categories)) {
            total += category.commands.length;
        }
        return total;
    }

    // Initialize with default commands
    initializeDefaultCommands() {
        // 👑 OWNER COMMANDS
        this.registerCommand('owner', 'features', 'Change bot prefix');
        this.registerCommand('owner', 'setprefix', 'Change bot prefix');
        this.registerCommand('owner', 'mode', 'Switch between public/private mode');
        this.registerCommand('owner', 'addsudo', 'Add sudo user');
        this.registerCommand('owner', 'delsudo', 'Remove sudo user');
        this.registerCommand('owner', 'antidelete', 'enable message delete recov');
        this.registerCommand('owner', 'antidemote', 'enable message delete recov');
        this.registerCommand('owner', 'autoview', 'enable message delete recov');
        this.registerCommand('owner', 'antispam', 'enable message delete recov');
        this.registerCommand('owner', 'antiedit', 'enable message delete recov');
        this.registerCommand('owner', 'autoreact', 'enable message delete recov');
        this.registerCommand('owner', 'autotyping', 'enable message delete recov');
        this.registerCommand('owner', 'autorecording', 'enable message delete recov');
        this.registerCommand('owner', 'broadcast', 'Broadcast message to all chats');
        this.registerCommand('owner', 'eval', 'Execute JavaScript code');
        this.registerCommand('owner', 'exec', 'Execute shell command');
        this.registerCommand('owner', 'backup', 'Backup bot data');
        this.registerCommand('owner', 'restart', 'Restart the bot');
        this.registerCommand('owner', 'shutdown', 'Shutdown the bot');

        // 👥 GROUP COMMANDS
        this.registerCommand('group', 'kick', 'Kick user from group', { groupOnly: true, requiresAdmin: true });
        this.registerCommand('group', 'promote', 'Promote user to admin', { groupOnly: true, requiresAdmin: true });
        this.registerCommand('group', 'demote', 'Demote admin to member', { groupOnly: true, requiresAdmin: true });
        this.registerCommand('group', 'tagall', 'Tag all group members', { groupOnly: true });
        this.registerCommand('group', 'groupinfo', 'Show group information', { groupOnly: true });
        this.registerCommand('group', 'antilink', 'Toggle anti-link protection', { groupOnly: true, requiresAdmin: true });
        this.registerCommand('group', 'welcome', 'Set welcome message', { groupOnly: true, requiresAdmin: true });
        this.registerCommand('group', 'setdesc', 'Set group description', { groupOnly: true, requiresAdmin: true });
        this.registerCommand('group', 'setname', 'Set group name', { groupOnly: true, requiresAdmin: true });
        this.registerCommand('group', 'close', 'Close group', { groupOnly: true, requiresAdmin: true });
        this.registerCommand('group', 'open', 'Open group', { groupOnly: true, requiresAdmin: true });

        // 🔧 GENERAL COMMANDS
        this.registerCommand('general', 'menu', 'Show this menu');
        this.registerCommand('general', 'ping', 'Test bot response');
        this.registerCommand('general', 'help', 'Get help for a command');
        this.registerCommand('general', 'stats', 'Show bot statistics');
        this.registerCommand('general', 'profile', 'Show user profile');
        this.registerCommand('general', 'listblock', 'List blocked users');
        this.registerCommand('general', 'runtime', 'Show bot uptime');
        this.registerCommand('general', 'speed', 'Test bot speed');

        // 🎮 FUN COMMANDS
        this.registerCommand('fun', 'joke', 'Get a random joke');
        this.registerCommand('fun', 'quote', 'Get inspirational quote');
        this.registerCommand('fun', 'fact', 'Get random fact');
        this.registerCommand('fun', 'meme', 'Get random meme');
        this.registerCommand('fun', 'coinflip', 'Flip a coin');
        this.registerCommand('fun', 'dice', 'Roll a dice');
        this.registerCommand('fun', '8ball', 'Magic 8 ball');
        this.registerCommand('fun', 'rate', 'Rate something');
        this.registerCommand('fun', 'ship', 'Ship two people');

        // 🛠️ TOOL COMMANDS
        this.registerCommand('tools', 'sticker', 'Create sticker from image');
        this.registerCommand('tools', 'crop', 'Crop image');
        this.registerCommand('tools', 'blur', 'Blur image');
        this.registerCommand('tools', 'rotate', 'Rotate image');
        this.registerCommand('tools', 'text2img', 'Convert text to image');
        this.registerCommand('tools', 'qr', 'Generate QR code');
        this.registerCommand('tools', 'calc', 'Calculator');
        this.registerCommand('tools', 'currency', 'Currency converter');
        this.registerCommand('tools', 'weather', 'Get weather information');

        // 📥 DOWNLOAD COMMANDS
        this.registerCommand('download', 'ytmp3', 'Download YouTube audio');
        this.registerCommand('download', 'ytmp4', 'Download YouTube video');
        this.registerCommand('download', 'tiktok', 'Download TikTok video');
        this.registerCommand('download', 'instagram', 'Download Instagram media');
        this.registerCommand('download', 'facebook', 'Download Facebook video');
        this.registerCommand('download', 'twitter', 'Download Twitter video');

        // 🔍 SEARCH COMMANDS
        this.registerCommand('search', 'google', 'Search on Google');
        this.registerCommand('search', 'youtube', 'Search on YouTube');
        this.registerCommand('search', 'wiki', 'Search Wikipedia');
        this.registerCommand('search', 'lyrics', 'Search song lyrics');
        this.registerCommand('search', 'movie', 'Search movie information');

        // 🤖 AI COMMANDS
        this.registerCommand('ai', 'gpt', 'Chat with GPT');
        this.registerCommand('ai', 'dalle', 'Generate image with DALL-E');
        this.registerCommand('ai', 'gemini', 'Chat with Gemini');
        this.registerCommand('ai', 'aiimg', 'AI image analysis');
        this.registerCommand('ai', 'chatbot', 'Chat with AI assistant (English/Kiswahili)');
        this.registerCommand('ai', 'ai', 'Alias for chatbot command');
        this.registerCommand('ai', 'translate', 'Translate text');

        // Add more commands as needed...
    }
}

// Create and initialize menu manager
const menuManager = new MenuManager();
menuManager.initializeDefaultCommands();

module.exports = menuManager;