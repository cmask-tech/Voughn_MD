// core/helpers/chatbot.js
const axios = require('axios');

class ChatbotHelper {
    constructor() {
        this.conversations = new Map(); // Store conversation history
    }

    // Option 1: Google Gemini API (Free tier, supports Kiswahili)
    static async geminiChat(prompt, language = 'en') {
        try {
            // Note: You need to get a free API key from https://makersuite.google.com/app/apikey
            const API_KEY = process.env.GEMINI_API_KEY || 'YOUR_GEMINI_API_KEY';
            
            const response = await axios.post(
                `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${API_KEY}`,
                {
                    contents: [{
                        parts: [{
                            text: `Respond in ${language}. User: ${prompt}`
                        }]
                    }]
                },
                {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            );

            return response.data.candidates[0].content.parts[0].text;
        } catch (error) {
            console.error('Gemini API Error:', error.response?.data || error.message);
            return this.fallbackResponse(prompt, language);
        }
    }

    // Option 2: Hugging Face Inference API (Free, supports Kiswahili)
    static async huggingFaceChat(prompt, language = 'en') {
        try {
            const API_KEY = process.env.HUGGINGFACE_API_KEY || 'YOUR_HUGGINGFACE_KEY';
            const model = 'microsoft/DialoGPT-medium'; // You can change to other models
            
            const response = await axios.post(
                `https://api-inference.huggingface.co/models/${model}`,
                {
                    inputs: prompt,
                    parameters: {
                        max_length: 150,
                        temperature: 0.7,
                        do_sample: true
                    }
                },
                {
                    headers: {
                        'Authorization': `Bearer ${API_KEY}`,
                        'Content-Type': 'application/json'
                    }
                }
            );

            return response.data[0].generated_text;
        } catch (error) {
            console.error('Hugging Face API Error:', error.response?.data || error.message);
            return this.fallbackResponse(prompt, language);
        }
    }

    // Option 3: OpenAI GPT (Supports Kiswahili, but paid)
    static async openAIChat(prompt, language = 'en') {
        try {
            const API_KEY = process.env.OPENAI_API_KEY || 'YOUR_OPENAI_KEY';
            
            const response = await axios.post(
                'https://api.openai.com/v1/chat/completions',
                {
                    model: 'gpt-3.5-turbo',
                    messages: [{
                        role: 'user',
                        content: `Respond in ${language}. ${prompt}`
                    }],
                    max_tokens: 150,
                    temperature: 0.7
                },
                {
                    headers: {
                        'Authorization': `Bearer ${API_KEY}`,
                        'Content-Type': 'application/json'
                    }
                }
            );

            return response.data.choices[0].message.content;
        } catch (error) {
            console.error('OpenAI API Error:', error.response?.data || error.message);
            return this.fallbackResponse(prompt, language);
        }
    }

    // Option 4: Custom AI Service with Kiswahili support
    static async customAIChat(prompt, language = 'en') {
        try {
            // You can use any other AI service that supports Kiswahili
            // For example: Cohere, Anthropic, or your own trained model
            
            const response = await axios.post('https://your-custom-ai-service.com/chat', {
                message: prompt,
                language: language,
                context: 'whatsapp_bot'
            });

            return response.data.reply;
        } catch (error) {
            return this.fallbackResponse(prompt, language);
        }
    }

    // Option 5: Free Translation-based Chatbot (Using Google Translate + Simple AI)
    static async translateBasedChat(prompt, language = 'en') {
        try {
            // First, detect language
            const detectedLang = await this.detectLanguage(prompt);
            
            // If already in target language, use simple AI
            if (detectedLang === language) {
                return this.simpleAIResponse(prompt, language);
            }

            // Translate to English for processing
            const translatedPrompt = await this.translateText(prompt, 'en');
            
            // Get response in English
            const englishResponse = await this.simpleAIResponse(translatedPrompt, 'en');
            
            // Translate back to target language
            const finalResponse = await this.translateText(englishResponse, language);
            
            return finalResponse;
        } catch (error) {
            return this.fallbackResponse(prompt, language);
        }
    }

    // Simple AI with Kiswahili support
    static simpleAIResponse(prompt, language = 'en') {
        const lowerPrompt = prompt.toLowerCase();
        
        // English responses
        const englishResponses = {
            'hello': '👋 Hello! How can I assist you today?',
            'hi': '👋 Hi there! Nice to meet you!',
            'how are you': 'I\'m doing great, thanks for asking! How about you?',
            'what is your name': 'I\'m Voughn_MD, your friendly WhatsApp assistant!',
            'who made you': 'I was created by the Voughn Team!',
            'thank you': 'You\'re welcome! 😊',
            'thanks': 'You\'re welcome! 😊',
            'bye': 'Goodbye! Have a wonderful day! 👋',
            'goodbye': 'See you later! Take care! 👋',
            'help': 'I can help with various tasks! Use .menu to see all available commands.',
            'what can you do': 'I can download media, search information, translate text, and much more! Check .menu for all features.',
            'joke': 'Why don\'t scientists trust atoms? Because they make up everything! 😄',
            'time': `🕐 Current time: ${new Date().toLocaleString()}`,
            'date': `📅 Today is: ${new Date().toLocaleDateString()}`,
            'weather': '🌤️ I can check weather! Use: .weather <city>',
            'love': '💖 That\'s so sweet! You have a beautiful heart!',
            'sad': '🤗 I\'m here for you! Everything will be okay. 💙'
        };

        // Kiswahili responses
        const kiswahiliResponses = {
            'hujambo': '👋 Hujambo! Ninawezaje kukusaidia leo?',
            'mambo': '👋 Mambo vipi! Karibu sana!',
            'habari': '👋 Habari yako? Nzuri sana, asante! Na wewe je?',
            'unaendeleaje': '👋 Niko sawa, asante! Na wewe unaendeleaje?',
            'jina lako nani': '👋 Jina langu ni Voughn_MD, msaidizi wako wa WhatsApp!',
            'nani alikutengeneza': '👋 Nilitengenezwa na Timu ya Voughn!',
            'asante': '👋 Karibu sana! 😊',
            'shukrani': '👋 Karibu sana! 😊',
            'kwaheri': '👋 Kwaheri! Uwe na siku njema!',
            'usaidizi': '👋 Ninaweza kusaidia kwa kazi mbalimbali! Tumia .menu kuona amri zote.',
            'unaweza kufanya nini': '👋 Ninaweza kupakua media, kutafuta habari, kutafsiri maandishi, na mengi zaidi! Angalia .menu kwa vipengele vyote.',
            'utani': '👋 Kwa nini wanasayansi hawaamini atomu? Kwa sababu hujifanya kila kitu! 😄',
            'saa': `🕐 Saa ya sasa: ${new Date().toLocaleString()}`,
            'tarehe': `📅 Tarehe ya leo: ${new Date().toLocaleDateString()}`,
            'hali ya hewa': '🌤️ Ninaweza kuangalia hali ya hewa! Tumia: .weather <mji>',
            'upendo': '💖 Hiyo ni tamu sana! Una moyo mzuri!',
            'huzuni': '🤗 Niko hapa kwa ajili yako! Kila kitu kitakuwa sawa. 💙'
        };

        const responses = language === 'sw' ? kiswahiliResponses : englishResponses;

        // Check for exact matches
        for (const [key, response] of Object.entries(responses)) {
            if (lowerPrompt.includes(key)) {
                return response;
            }
        }

        // Language-specific default responses
        const defaultResponses = {
            'en': [
                '🤔 I\'m not sure I understand. Could you rephrase that?',
                '💭 That\'s interesting! Can you tell me more?',
                '🎯 I\'m still learning. Could you try asking differently?',
                '📚 I\'m here to help! What would you like to know?',
                '🌟 Great question! I\'m constantly improving my knowledge.',
                '🔍 Try using .google or .wiki commands for specific information!',
                '💡 You can ask me about various topics or use .menu for commands.'
            ],
            'sw': [
                '🤔 Sielewi vizuri. Unaweza kusema kwa njia nyingine?',
                '💭 Hiyo ni ya kuvutia! Unaweza kuniambia zaidi?',
                '🎯 Bado ninajifunza. Unaweza kujaribu kuuliza kwa njia tofauti?',
                '📚 Niko hapa kukusaidia! Ungependa kujua nini?',
                '🌟 Swali zuri! Ninaendelea kuboresha ujuzi wangu.',
                '🔍 Jaribu kutumia amri za .google au .wiki kwa habari maalum!',
                '💡 Unaweza kuniuliza kuhusu mada mbalimbali au tumia .menu kwa amri.'
            ]
        };

        const randomIndex = Math.floor(Math.random() * defaultResponses[language].length);
        return defaultResponses[language][randomIndex];
    }

    // Language detection (simplified)
    static async detectLanguage(text) {
        const kiswahiliWords = ['hujambo', 'mambo', 'habari', 'asante', 'sawa', 'hapana', 'ndio', 'pole', 'karibu'];
        const lowerText = text.toLowerCase();
        
        for (const word of kiswahiliWords) {
            if (lowerText.includes(word)) {
                return 'sw';
            }
        }
        
        return 'en';
    }

    // Simple translation function (you might want to use a proper translation API)
    static async translateText(text, targetLang) {
        // This is a simplified version - in production, use Google Translate API
        const translations = {
            'hello': {
                'sw': 'hujambo'
            },
            'hi': {
                'sw': 'mambo'
            },
            'how are you': {
                'sw': 'habari yako'
            },
            'thank you': {
                'sw': 'asante'
            }
            // Add more translations as needed
        };

        const lowerText = text.toLowerCase();
        for (const [english, langMap] of Object.entries(translations)) {
            if (lowerText.includes(english) && langMap[targetLang]) {
                return langMap[targetLang];
            }
        }

        return text; // Return original if no translation found
    }

    // Fallback response
    static fallbackResponse(prompt, language = 'en') {
        const fallbacks = {
            'en': '🤖 I apologize, but I\'m having trouble connecting to my AI services right now. Please try again later or use other bot commands!',
            'sw': '🤖 Samahani, nina shida ya kuungana na huduma zangu za AI kwa sasa. Tafadhali jaribu tena baadaye au tumia amri nyingine za bot!'
        };
        
        return fallbacks[language] || fallbacks['en'];
    }

    // Main chatbot method - tries different APIs in order
    static async chat(prompt, userId, language = 'auto') {
        try {
            // Auto-detect language if not specified
            let targetLanguage = language;
            if (language === 'auto') {
                targetLanguage = await this.detectLanguage(prompt);
            }

            // Try different APIs in order of preference
            let response;
            
            // 1. First try Gemini (free and good)
            try {
                response = await this.geminiChat(prompt, targetLanguage);
                if (response && !response.includes('API key')) {
                    return response;
                }
            } catch (e) { /* Continue to next option */ }

            // 2. Try Hugging Face
            try {
                response = await this.huggingFaceChat(prompt, targetLanguage);
                if (response) return response;
            } catch (e) { /* Continue to next option */ }

            // 3. Fallback to simple AI with language support
            response = this.simpleAIResponse(prompt, targetLanguage);
            return response;

        } catch (error) {
            console.error('Chatbot error:', error);
            return this.fallbackResponse(prompt, language === 'auto' ? 'en' : language);
        }
    }
}

module.exports = ChatbotHelper;