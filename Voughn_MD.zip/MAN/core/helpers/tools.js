// core/helpers/tools.js
const axios = require('axios');
const qrcode = require('qrcode');
const sharp = require('sharp');

class ToolsHelper {
    static async getWeather(city) {
        try {
            // Using openweathermap API (you'll need to get a free API key)
            const response = await axios.get(`http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=YOUR_API_KEY&units=metric`);
            const data = response.data;
            return `🌤️ Weather in ${data.name}:
🌡️ Temperature: ${data.main.temp}°C
💨 Humidity: ${data.main.humidity}%
🌬️ Wind: ${data.wind.speed} m/s
☁️ Condition: ${data.weather[0].description}`;
        } catch (error) {
            return `❌ Could not get weather for ${city}. Please check the city name.`;
        }
    }

    static async generateQR(text) {
        try {
            const qrDataUrl = await qrcode.toDataURL(text);
            return qrDataUrl;
        } catch (error) {
            throw new Error('Failed to generate QR code');
        }
    }

    static calculate(expression) {
        try {
            // Safe evaluation - only allow basic math operations
            const safeExpression = expression.replace(/[^0-9+\-*/().]/g, '');
            const result = eval(safeExpression);
            return `🧮 Calculation: ${expression} = ${result}`;
        } catch (error) {
            return '❌ Invalid mathematical expression';
        }
    }

    static convertCurrency(amount, from, to) {
        // This is a simplified version - you'd need a real API for accurate rates
        const rates = {
            USD: 1,
            EUR: 0.85,
            GBP: 0.73,
            JPY: 110.5,
            CAD: 1.25,
            AUD: 1.35,
            CNY: 6.45,
            INR: 74.5,
            KES: 110.5
        };

        if (!rates[from] || !rates[to]) {
            return '❌ Unsupported currency';
        }

        const converted = (amount * rates[to] / rates[from]).toFixed(2);
        return `💱 ${amount} ${from} = ${converted} ${to}`;
    }

    static async createSticker(imageBuffer) {
        try {
            // Use sharp to resize and convert to PNG for stickers
            const stickerBuffer = await sharp(imageBuffer)
                .resize(512, 512)
                .png()
                .toBuffer();
            return stickerBuffer;
        } catch (error) {
            throw new Error('Failed to create sticker');
        }
    }

    static async textToImage(text) {
        try {
            // Create SVG with text and convert to PNG using sharp
            const svgImage = `
                <svg width="800" height="400" xmlns="http://www.w3.org/2000/svg">
                    <rect width="100%" height="100%" fill="#2d3436"/>
                    <text x="50%" y="50%" font-family="Arial" font-size="40" fill="white" text-anchor="middle" dominant-baseline="middle">${text}</text>
                </svg>
            `;
            
            const imageBuffer = await sharp(Buffer.from(svgImage))
                .png()
                .toBuffer();
                
            return imageBuffer;
        } catch (error) {
            throw new Error('Failed to create text image');
        }
    }

    // Additional helper methods with sharp
    static async resizeImage(buffer, width = 512, height = 512) {
        return await sharp(buffer)
            .resize(width, height)
            .png()
            .toBuffer();
    }

    static async blurImage(buffer, sigma = 5) {
        return await sharp(buffer)
            .blur(sigma)
            .png()
            .toBuffer();
    }

    static async rotateImage(buffer, degrees = 90) {
        return await sharp(buffer)
            .rotate(degrees)
            .png()
            .toBuffer();
    }
}

module.exports = ToolsHelper;