// core/commands.js
const database = require('./database');
const { extractPhoneFromJid, isGroupJid, colorful } = require('./utils');
const menuManager = require('./menu');
const FunHelper = require('./helpers/fun');
const ToolsHelper = require('./helpers/tools');
// Add these imports at the top of core/commands.js
const DownloadHelper = require('./helpers/downloader');
const SearchHelper = require('./helpers/search');
const AIHelper = require('./helpers/ai');
const ChatbotHelper = require('./helpers/chatbot');
const fs = require('fs');
const axios = require('axios');

const commands = {
    // 👑 OWNER COMMANDS
    setprefix: {
        ownerOnly: true,
        description: 'Change bot command prefix',
        async execute(sock, message, args, bot) {
            const newPrefix = args[0];
            if (!newPrefix) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a prefix. Example: .setprefix !'
                });
                return;
            }
            
            await database.updatePrefix(newPrefix);
            await sock.sendMessage(message.key.remoteJid, {
                text: `✅ Prefix updated to: ${newPrefix}`
            });
        }
    },

    mode: {
        ownerOnly: true,
        description: 'Switch between public and private mode',
        async execute(sock, message, args, bot) {
            const mode = args[0]?.toLowerCase();
            if (!mode || !['public', 'private'].includes(mode)) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please specify: public or private'
                });
                return;
            }
            
            await database.updateMode(mode);
            await sock.sendMessage(message.key.remoteJid, {
                text: `✅ Mode set to: ${mode}`
            });
        }
    },

    addsudo: {
        ownerOnly: true,
        description: 'Add sudo user',
        async execute(sock, message, args, bot) {
            if (!message.message?.extendedTextMessage?.contextInfo?.participant) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please reply to a user message'
                });
                return;
            }
            
            const targetJid = message.message.extendedTextMessage.contextInfo.participant;
            const phone = extractPhoneFromJid(targetJid);
            const ownerJid = message.key.participant || message.key.remoteJid;
            
            const success = await database.addSudoUser(targetJid, phone, ownerJid);
            if (success) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: `✅ Added ${phone} as sudo user`
                });
            } else {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Failed to add sudo user'
                });
            }
        }
    },

    delsudo: {
        ownerOnly: true,
        description: 'Remove sudo user',
        async execute(sock, message, args, bot) {
            if (!message.message?.extendedTextMessage?.contextInfo?.participant) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please reply to a user message'
                });
                return;
            }
            
            const targetJid = message.message.extendedTextMessage.contextInfo.participant;
            await database.removeSudoUser(targetJid);
            await sock.sendMessage(message.key.remoteJid, {
                text: '✅ Sudo user removed'
            });
        }
    },

    broadcast: {
        ownerOnly: true,
        description: 'Broadcast message to all chats',
        async execute(sock, message, args, bot) {
            const broadcastMessage = args.join(' ');
            if (!broadcastMessage) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a message to broadcast'
                });
                return;
            }

            // In a real implementation, you'd get all chats from database
            await sock.sendMessage(message.key.remoteJid, {
                text: `📢 Broadcast feature would send: "${broadcastMessage}" to all chats`
            });
        }
    },

    restart: {
        ownerOnly: true,
        description: 'Restart the bot',
        async execute(sock, message, args, bot) {
            await sock.sendMessage(message.key.remoteJid, {
                text: '🔄 Restarting bot...'
            });
            setTimeout(() => {
                process.exit(0);
            }, 2000);
        }
    },

    // 👥 GROUP COMMANDS
    kick: {
        groupOnly: true,
        requiresAdmin: true,
        description: 'Kick user from group',
        async execute(sock, message, args, bot) {
            if (!message.message?.extendedTextMessage?.contextInfo?.participant) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please reply to user to kick'
                });
                return;
            }
            
            const targetJid = message.message.extendedTextMessage.contextInfo.participant;
            try {
                await sock.groupParticipantsUpdate(message.key.remoteJid, [targetJid], 'remove');
                await sock.sendMessage(message.key.remoteJid, {
                    text: '✅ User kicked successfully'
                });
            } catch (error) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Failed to kick user. Make sure I\'m admin.'
                });
            }
        }
    },

    promote: {
        groupOnly: true,
        requiresAdmin: true,
        description: 'Promote user to admin',
        async execute(sock, message, args, bot) {
            if (!message.message?.extendedTextMessage?.contextInfo?.participant) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please reply to user to promote'
                });
                return;
            }
            
            const targetJid = message.message.extendedTextMessage.contextInfo.participant;
            try {
                await sock.groupParticipantsUpdate(message.key.remoteJid, [targetJid], 'promote');
                await sock.sendMessage(message.key.remoteJid, {
                    text: '✅ User promoted to admin'
                });
            } catch (error) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Failed to promote user'
                });
            }
        }
    },

    demote: {
        groupOnly: true,
        requiresAdmin: true,
        description: 'Demote admin to member',
        async execute(sock, message, args, bot) {
            if (!message.message?.extendedTextMessage?.contextInfo?.participant) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please reply to admin to demote'
                });
                return;
            }
            
            const targetJid = message.message.extendedTextMessage.contextInfo.participant;
            try {
                await sock.groupParticipantsUpdate(message.key.remoteJid, [targetJid], 'demote');
                await sock.sendMessage(message.key.remoteJid, {
                    text: '✅ Admin demoted to member'
                });
            } catch (error) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Failed to demote user'
                });
            }
        }
    },

    tagall: {
        groupOnly: true,
        description: 'Tag all group members',
        async execute(sock, message, args, bot) {
            try {
                const groupMetadata = await sock.groupMetadata(message.key.remoteJid);
                const participants = groupMetadata.participants;
                let tagMessage = args.join(' ') || 'Hello everyone! ';
                
                participants.forEach(participant => {
                    tagMessage += `@${participant.id.split('@')[0]} `;
                });
                
                await sock.sendMessage(message.key.remoteJid, { 
                    text: tagMessage,
                    mentions: participants.map(p => p.id)
                });
            } catch (error) {
                await sock.sendMessage(message.key.remoteJid, { 
                    text: '❌ Failed to tag members'
                });
            }
        }
    },

    groupinfo: {
        groupOnly: true,
        description: 'Show group information',
        async execute(sock, message, args, bot) {
            try {
                const groupMetadata = await sock.groupMetadata(message.key.remoteJid);
                const infoText = `
🏷️ *Group Info:*
├─ Name: ${groupMetadata.subject}
├─ Participants: ${groupMetadata.participants.length}
├─ Created: ${new Date(groupMetadata.creation * 1000).toLocaleDateString()}
├─ Description: ${groupMetadata.desc || 'No description'}
╰─ ID: ${groupMetadata.id}
                `.trim();
                
                await sock.sendMessage(message.key.remoteJid, { text: infoText });
            } catch (error) {
                await sock.sendMessage(message.key.remoteJid, { 
                    text: '❌ Failed to get group info'
                });
            }
        }
    },

    // 🔧 GENERAL COMMANDS
    ping: {
        description: 'Test bot response time',
        async execute(sock, message, args, bot) {
            const start = Date.now();
            const sentMsg = await sock.sendMessage(message.key.remoteJid, {
                text: '🏓 Pong!'
            });
            const latency = Date.now() - start;
            await sock.sendMessage(message.key.remoteJid, {
                text: `⏱️ SPEED: ${latency}ms\n💻 Server: Online`
            });
        }
    },

    menu: {
        description: 'Show all available commands',
        async execute(sock, message, args, bot) {
            const prefix = (await database.getBotSettings()).prefix;
            const userJid = message.key.participant || message.key.remoteJid;
            const menuText = await menuManager.generateMenu(prefix, userJid);
            
            await sock.sendMessage(message.key.remoteJid, { text: menuText });
        }
    },

    help: {
        description: 'Get detailed help for a command',
        async execute(sock, message, args, bot) {
            const prefix = (await database.getBotSettings()).prefix;
            const commandName = args[0];
            const userJid = message.key.participant || message.key.remoteJid;
            
            if (!commandName) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: `❌ Please specify a command. Usage: ${prefix}help <command>`
                });
                return;
            }
            
            const helpText = await menuManager.generateCommandHelp(prefix, commandName, userJid);
            await sock.sendMessage(message.key.remoteJid, { text: helpText });
        }
    },

    stats: {
        description: 'Show bot statistics',
        async execute(sock, message, args, bot) {
            const statsText = `
📊 *Bot Statistics*
├─ Uptime: ${Math.floor(process.uptime() / 60)} minutes
├─ Memory: ${Math.round(process.memoryUsage().rss / 1024 / 1024)}MB
├─ Platform: ${process.platform}
├─ Node.js: ${process.version}
╰─ Commands: ${menuManager.getTotalCommands()} total
            `.trim();
            
            await sock.sendMessage(message.key.remoteJid, { text: statsText });
        }
    },

    // 🎮 FUN COMMANDS
    joke: {
        description: 'Get a random joke',
        async execute(sock, message, args, bot) {
            const joke = await FunHelper.getJoke();
            await sock.sendMessage(message.key.remoteJid, { text: `😂 Joke:\n${joke}` });
        }
    },

    quote: {
        description: 'Get inspirational quote',
        async execute(sock, message, args, bot) {
            const quote = await FunHelper.getQuote();
            await sock.sendMessage(message.key.remoteJid, { text: `💫 Quote:\n${quote}` });
        }
    },

    fact: {
        description: 'Get random fact',
        async execute(sock, message, args, bot) {
            const fact = await FunHelper.getFact();
            await sock.sendMessage(message.key.remoteJid, { text: `📚 Fact:\n${fact}` });
        }
    },

    coinflip: {
        description: 'Flip a coin',
        async execute(sock, message, args, bot) {
            const result = FunHelper.coinFlip();
            await sock.sendMessage(message.key.remoteJid, { text: `🎯 Coin Flip:\n${result}` });
        }
    },

    dice: {
        description: 'Roll a dice',
        async execute(sock, message, args, bot) {
            const result = FunHelper.rollDice();
            await sock.sendMessage(message.key.remoteJid, { text: `🎲 Dice Roll:\n${result}` });
        }
    },

    '8ball': {
        description: 'Magic 8 ball',
        async execute(sock, message, args, bot) {
            const question = args.join(' ');
            if (!question) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please ask a question. Example: .8ball Will I win the lottery?'
                });
                return;
            }
            
            const answer = FunHelper.magic8Ball();
            await sock.sendMessage(message.key.remoteJid, {
                text: `🎱 Question: ${question}\nAnswer: ${answer}`
            });
        }
    },

    rate: {
        description: 'Rate something',
        async execute(sock, message, args, bot) {
            const thing = args.join(' ');
            if (!thing) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please specify what to rate. Example: .rate pizza'
                });
                return;
            }
            
            const rating = FunHelper.rateSomething(thing);
            await sock.sendMessage(message.key.remoteJid, { text: rating });
        }
    },

    ship: {
        description: 'Ship two people',
        async execute(sock, message, args, bot) {
            if (args.length < 2) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please specify two people. Example: .ship John Mary'
                });
                return;
            }
            
            const result = FunHelper.shipPeople(args[0], args[1]);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    // 🛠️ TOOL COMMANDS
    qr: {
        description: 'Generate QR code',
        async execute(sock, message, args, bot) {
            const text = args.join(' ');
            if (!text) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide text for QR code. Example: .qr https://google.com'
                });
                return;
            }

            try {
                const qrBuffer = await ToolsHelper.generateQR(text);
                await sock.sendMessage(message.key.remoteJid, {
                    image: Buffer.from(qrBuffer.split(',')[1], 'base64'),
                    caption: `📲 QR Code for: ${text}`
                });
            } catch (error) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Failed to generate QR code'
                });
            }
        }
    },

    calc: {
        description: 'Calculator',
        async execute(sock, message, args, bot) {
            const expression = args.join(' ');
            if (!expression) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a calculation. Example: .calc 2+2*3'
                });
                return;
            }

            const result = ToolsHelper.calculate(expression);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    currency: {
        description: 'Currency converter',
        async execute(sock, message, args, bot) {
            if (args.length < 3) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Usage: .currency <amount> <from> <to>\nExample: .currency 100 USD EUR'
                });
                return;
            }

            const amount = parseFloat(args[0]);
            const from = args[1].toUpperCase();
            const to = args[2].toUpperCase();

            if (isNaN(amount)) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a valid amount'
                });
                return;
            }

            const result = ToolsHelper.convertCurrency(amount, from, to);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    // Add more commands as needed...
    echo: {
        description: 'Echo your message back',
        async execute(sock, message, args, bot) {
            const text = args.join(' ') || 'Hello!';
            await sock.sendMessage(message.key.remoteJid, {
                text: `🔊 Echo: ${text}`
            });
        }
    },

    // 📥 DOWNLOAD COMMANDS
    ytmp3: {
        description: 'Download YouTube audio',
        async execute(sock, message, args, bot) {
            const url = args[0];
            if (!url) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a YouTube URL. Example: .ytmp3 https://youtube.com/watch?v=...'
                });
                return;
            }

            const result = await DownloadHelper.downloadYouTubeAudio(url);
            await sock.sendMessage(message.key.remoteJid, { text: result.message });
        }
    },

    ytmp4: {
        description: 'Download YouTube video',
        async execute(sock, message, args, bot) {
            const url = args[0];
            if (!url) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a YouTube URL. Example: .ytmp4 https://youtube.com/watch?v=...'
                });
                return;
            }

            const result = await DownloadHelper.downloadYouTubeVideo(url);
            await sock.sendMessage(message.key.remoteJid, { text: result.message });
        }
    },

    tiktok: {
        description: 'Download TikTok video',
        async execute(sock, message, args, bot) {
            const url = args[0];
            if (!url) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a TikTok URL. Example: .tiktok https://tiktok.com/@user/video/...'
                });
                return;
            }

            const result = await DownloadHelper.downloadTikTok(url);
            await sock.sendMessage(message.key.remoteJid, { text: result.message });
        }
    },

    instagram: {
        description: 'Download Instagram media',
        async execute(sock, message, args, bot) {
            const url = args[0];
            if (!url) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide an Instagram URL. Example: .instagram https://instagram.com/p/...'
                });
                return;
            }

            const result = await DownloadHelper.downloadInstagram(url);
            await sock.sendMessage(message.key.remoteJid, { text: result.message });
        }
    },

    facebook: {
        description: 'Download Facebook video',
        async execute(sock, message, args, bot) {
            const url = args[0];
            if (!url) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a Facebook URL. Example: .facebook https://facebook.com/watch/?v=...'
                });
                return;
            }

            const result = await DownloadHelper.downloadFacebook(url);
            await sock.sendMessage(message.key.remoteJid, { text: result.message });
        }
    },

    twitter: {
        description: 'Download Twitter video',
        async execute(sock, message, args, bot) {
            const url = args[0];
            if (!url) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a Twitter URL. Example: .twitter https://twitter.com/user/status/...'
                });
                return;
            }

            const result = await DownloadHelper.downloadTwitter(url);
            await sock.sendMessage(message.key.remoteJid, { text: result.message });
        }
    },

    // 🔍 SEARCH COMMANDS
    google: {
        description: 'Search on Google',
        async execute(sock, message, args, bot) {
            const query = args.join(' ');
            if (!query) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a search query. Example: .google artificial intelligence'
                });
                return;
            }

            const result = await SearchHelper.searchGoogle(query);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    youtube: {
        description: 'Search on YouTube',
        async execute(sock, message, args, bot) {
            const query = args.join(' ');
            if (!query) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a search query. Example: .youtube funny cat videos'
                });
                return;
            }

            const result = await SearchHelper.searchYouTube(query);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    wiki: {
        description: 'Search Wikipedia',
        async execute(sock, message, args, bot) {
            const query = args.join(' ');
            if (!query) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a search query. Example: .wiki Albert Einstein'
                });
                return;
            }

            const result = await SearchHelper.searchWikipedia(query);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    lyrics: {
        description: 'Search song lyrics',
        async execute(sock, message, args, bot) {
            const song = args.join(' ');
            if (!song) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a song name. Example: .lyrics "Bohemian Rhapsody"'
                });
                return;
            }

            const result = await SearchHelper.searchLyrics(song);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    movie: {
        description: 'Search movie information',
        async execute(sock, message, args, bot) {
            const title = args.join(' ');
            if (!title) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a movie title. Example: .movie Inception'
                });
                return;
            }

            const result = await SearchHelper.searchMovie(title);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    // 🤖 AI COMMANDS
    gpt: {
        description: 'Chat with GPT',
        async execute(sock, message, args, bot) {
            const prompt = args.join(' ');
            if (!prompt) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a prompt. Example: .gpt Explain quantum computing'
                });
                return;
            }

            const result = await AIHelper.chatGPT(prompt);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    dalle: {
        description: 'Generate image with DALL-E',
        async execute(sock, message, args, bot) {
            const prompt = args.join(' ');
            if (!prompt) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a prompt. Example: .dalle a cute cat wearing sunglasses'
                });
                return;
            }

            const result = await AIHelper.dalle(prompt);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    gemini: {
        description: 'Chat with Gemini',
        async execute(sock, message, args, bot) {
            const prompt = args.join(' ');
            if (!prompt) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide a prompt. Example: .gemini How does machine learning work?'
                });
                return;
            }

            const result = await AIHelper.gemini(prompt);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    aiimg: {
        description: 'AI image analysis',
        async execute(sock, message, args, bot) {
            // Check if this is a reply to an image
            if (!message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please reply to an image with this command to analyze it.'
                });
                return;
            }

            const result = await AIHelper.analyzeImage('image_data');
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    translate: {
        description: 'Translate text',
        async execute(sock, message, args, bot) {
            if (args.length < 2) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Usage: .translate <text> <language_code>\nExample: .translate hello es\n\n🌐 Language codes: en, es, fr, de, it, pt, ru, ja, ko, zh, ar, hi, sw'
                });
                return;
            }

            const targetLang = args.pop();
            const text = args.join(' ');
            
            const result = await AIHelper.translate(text, targetLang);
            await sock.sendMessage(message.key.remoteJid, { text: result });
        }
    },

    // 📷 MEDIA COMMANDS (Basic implementations)
    sticker: {
        description: 'Create sticker from image',
        async execute(sock, message, args, bot) {
            // Check if this is a reply to an image
            if (!message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please reply to an image with this command to convert it to a sticker.'
                });
                return;
            }

            await sock.sendMessage(message.key.remoteJid, {
                text: '🔄 Converting image to sticker...\n\n💡 Sticker creation would process the image and send it as a sticker.'
            });
        }
    },

// In your commands, update the text2img command:
    text2img: {
        description: 'Convert text to image',
        async execute(sock, message, args, bot) {
            const text = args.join(' ');
            if (!text) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Please provide text. Example: .text2img Hello World'
                });
                return;
            }

            try {
                const imageBuffer = await ToolsHelper.textToImage(text);
                await sock.sendMessage(message.key.remoteJid, {
                    image: imageBuffer,
                    caption: `📝 Text: ${text}`
                });
            } catch (error) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Failed to create text image'
                });
            }
        }
    },
    // Add this to your core/commands.js file, after the other commands:


    // Add the chatbot command:
    chatbot: {
        description: 'Chat with AI assistant (supports English & Kiswahili)',
        async execute(sock, message, args, bot) {
            const prompt = args.join(' ');
            if (!prompt) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: `💬 *Chatbot Usage:*\n\n.chatbot <your message>\n\n🌍 *Supports:* English & Kiswahili\n💡 *Examples:*\n.chatbot Hello\n.chatbot Hujambo\n.chatbot Unaweza kunisaidia nini?\n.chatbot What can you do?`
                });
                return;
            }

            // Show typing indicator
            await sock.sendPresenceUpdate('composing', message.key.remoteJid);

            try {
                const response = await ChatbotHelper.chat(prompt, message.key.remoteJid);
                await sock.sendMessage(message.key.remoteJid, { text: response });
            } catch (error) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: '❌ Sorry, I encountered an error while processing your message. Please try again.'
                });
            } finally {
                await sock.sendPresenceUpdate('paused', message.key.remoteJid);
            }
        }
    },

    // Add AI command alias
    ai: {
        description: 'Alias for .chatbot - Chat with AI',
        async execute(sock, message, args, bot) {
            // Reuse the chatbot logic
            const commands = require('./commands');
            await commands.chatbot.execute(sock, message, args, bot);
        }
    },


    features: {
        ownerOnly: true,
        description: 'Enable/disable auto-features',
        async execute(sock, message, args, bot) {
            const action = args[0]?.toLowerCase();
            const feature = args[1]?.toLowerCase();
            
            const availableFeatures = {
                'antidelete': 'Anti-delete protection',
                'antiedit': 'Anti-edit protection', 
                'antidemote': 'Anti-demote protection',
                'antispam': 'Anti-spam protection',
                'autoview': 'Auto-view status',
                'autoreact': 'Auto-react to status',
                'autotyping': 'Auto-typing indicators',
                'autorecording': 'Auto-recording indicators'
            };

            if (!action || !['enable', 'disable', 'list'].includes(action)) {
                let featuresList = '⚙️ *AVAILABLE FEATURES*\n━━━━━━━━━━━━━━━━━━━━\n';
                for (const [key, desc] of Object.entries(availableFeatures)) {
                    featuresList += `• ${key} - ${desc}\n`;
                }
                featuresList += '\n💡 Usage: .features enable antidelete';
                
                await sock.sendMessage(message.key.remoteJid, { text: featuresList });
                return;
            }

            if (action === 'list') {
                // Show current feature status
                await sock.sendMessage(message.key.remoteJid, {
                    text: '📊 Feature status would be shown here'
                });
                return;
            }

            if (!feature || !availableFeatures[feature]) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: `❌ Unknown feature. Available: ${Object.keys(availableFeatures).join(', ')}`
                });
                return;
            }

            await sock.sendMessage(message.key.remoteJid, {
                text: `✅ ${action === 'enable' ? 'Enabled' : 'Disabled'} ${availableFeatures[feature]}`
            });
        }
    },

    antidelete: {
        groupOnly: true,
        requiresAdmin: true,
        description: 'Toggle anti-delete in this group',
        async execute(sock, message, args, bot) {
            const groupJid = message.key.remoteJid;
            // Implementation for group-specific anti-delete
            await sock.sendMessage(groupJid, {
                text: '🛡️ Anti-delete enabled'
            });
        }
    }
};

module.exports = commands;