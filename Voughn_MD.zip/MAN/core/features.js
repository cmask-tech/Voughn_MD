// core/features.js
const database = require('./database');
const { colorful, extractPhoneFromJid, isGroupJid } = require('./utils');

class Features {
    constructor(bot) {
        this.bot = bot;
        this.sock = null;
        this.deletedMessages = new Map();
        this.editedMessages = new Map();
        this.userActivity = new Map();
    }

    setSocket(sock) {
        this.sock = sock;
    }

    // ==================== ANTI-DELETE FEATURE ====================
    async setupAntiDelete() {
        this.sock.ev.on('messages.delete', async (deleteData) => {
            if (!deleteData.keys || !this.bot.ownerJid) return;
            
            for (const key of deleteData.keys) {
                try {
                    // Get message from cache or recent messages
                    const deletedMessage = this.deletedMessages.get(key.id) || 
                                         await this.findRecentMessage(key);
                    
                    if (deletedMessage) {
                        const content = this.extractMessageContent(deletedMessage);
                        const deleter = key.participant || 'Unknown';
                        
                        // Log to database
                        await database.logDeletedMessage(
                            key.remoteJid, 
                            deleter, 
                            content, 
                            deletedMessage.message ? Object.keys(deletedMessage.message)[0] : 'text'
                        );

                        // Send notification to owner
                        const deleteInfo = `
🚨 *MESSAGE DELETED* 🚨
━━━━━━━━━━━━━━━━━━━━
👤 *Deleted By:* ${deleter}
💬 *Content:* ${content.substring(0, 200)}${content.length > 200 ? '...' : ''}
📱 *Chat:* ${key.remoteJid}
⏰ *Time:* ${new Date().toLocaleString()}
                        `.trim();

                        await this.sock.sendMessage(this.bot.ownerJid, { text: deleteInfo });
                        
                        // Also notify in group if enabled
                        if (isGroupJid(key.remoteJid)) {
                            const groupSettings = await database.getGroupSettings(key.remoteJid);
                            if (groupSettings?.antidelete) {
                                await this.sock.sendMessage(key.remoteJid, {
                                    text: `⚠️ @${deleter.split('@')[0]} deleted a message!`,
                                    mentions: [deleter]
                                });
                            }
                        }
                    }
                } catch (error) {
                    colorful.error(`Anti-delete error: ${error.message}`);
                }
            }
        });
    }

    // ==================== ANTI-EDIT FEATURE ====================
    async setupAntiEdit() {
        this.sock.ev.on('messages.update', async (updates) => {
            for (const update of updates) {
                if (update.update?.message?.protocolMessage?.editedMessage && this.bot.ownerJid) {
                    try {
                        const originalMessage = this.editedMessages.get(update.key.id);
                        const editedMessage = update.update.message.protocolMessage.editedMessage;
                        
                        if (originalMessage) {
                            const originalContent = this.extractMessageContent(originalMessage);
                            const editedContent = this.extractMessageContent({ message: editedMessage });
                            const editor = update.key.participant || 'Unknown';

                            // Log to database
                            await database.logEditedMessage(
                                update.key.remoteJid,
                                editor,
                                originalContent,
                                editedContent
                            );

                            // Send notification to owner
                            const editInfo = `
🚨 *MESSAGE EDITED* 🚨
━━━━━━━━━━━━━━━━━━━━
👤 *Edited By:* ${editor}
📜 *Original:* ${originalContent.substring(0, 150)}${originalContent.length > 150 ? '...' : ''}
📝 *Edited:* ${editedContent.substring(0, 150)}${editedContent.length > 150 ? '...' : ''}
📱 *Chat:* ${update.key.remoteJid}
⏰ *Time:* ${new Date().toLocaleString()}
                            `.trim();

                            await this.sock.sendMessage(this.bot.ownerJid, { text: editInfo });
                        }
                    } catch (error) {
                        colorful.error(`Anti-edit error: ${error.message}`);
                    }
                }
            }
        });
    }

    // ==================== AUTO-VIEW STATUS ====================
    async setupAutoViewStatus() {
        this.sock.ev.on('messages.upsert', async (m) => {
            if (m.type === 'notify') {
                for (const msg of m.messages) {
                    // Auto-view status updates
                    if (msg.key.remoteJid === 'status@broadcast') {
                        try {
                            await this.sock.readMessages([msg.key]);
                            colorful.info(`👀 Auto-viewed status update`);
                        } catch (error) {
                            // Silent fail
                        }
                    }
                }
            }
        });
    }

    // ==================== AUTO-REACT STATUS ====================
    async setupAutoReactStatus() {
        this.sock.ev.on('messages.upsert', async (m) => {
            if (m.type === 'notify') {
                for (const msg of m.messages) {
                    if (msg.key.remoteJid === 'status@broadcast') {
                        try {
                            // Auto-react with random emoji
                            const reactions = ['👍', '❤️', '🔥', '😂', '😮', '😢'];
                            const randomReaction = reactions[Math.floor(Math.random() * reactions.length)];
                            
                            await this.sock.sendMessage(msg.key.remoteJid, {
                                react: {
                                    text: randomReaction,
                                    key: msg.key
                                }
                            });
                            colorful.info(`🎭 Auto-reacted to status: ${randomReaction}`);
                        } catch (error) {
                            // Silent fail
                        }
                    }
                }
            }
        });
    }

    // ==================== AUTO-TYPING INDICATOR ====================
    async setupAutoTyping() {
        this.sock.ev.on('messages.upsert', async (m) => {
            if (m.type === 'notify') {
                for (const msg of m.messages) {
                    // Auto-typing in response to messages
                    if (!msg.key.fromMe && msg.message?.conversation) {
                        try {
                            await this.sock.sendPresenceUpdate('composing', msg.key.remoteJid);
                            
                            // Stop typing after 2-5 seconds randomly
                            setTimeout(async () => {
                                await this.sock.sendPresenceUpdate('paused', msg.key.remoteJid);
                            }, 2000 + Math.random() * 3000);
                            
                        } catch (error) {
                            // Silent fail
                        }
                    }
                }
            }
        });
    }

    // ==================== AUTO-RECORDING INDICATOR ====================
    async setupAutoRecording() {
        this.sock.ev.on('messages.upsert', async (m) => {
            if (m.type === 'notify') {
                for (const msg of m.messages) {
                    // Auto-recording for voice messages
                    if (!msg.key.fromMe && msg.message?.audioMessage) {
                        try {
                            await this.sock.sendPresenceUpdate('recording', msg.key.remoteJid);
                            
                            setTimeout(async () => {
                                await this.sock.sendPresenceUpdate('paused', msg.key.remoteJid);
                            }, 3000);
                            
                            colorful.info(`🎙️ Auto-recording indicator shown`);
                        } catch (error) {
                            // Silent fail
                        }
                    }
                }
            }
        });
    }

    // ==================== ANTI-BUG FEATURE ====================
    async setupAntiBug() {
        this.sock.ev.on('messages.upsert', async (m) => {
            if (m.type === 'notify') {
                for (const msg of m.messages) {
                    if (!msg.key.fromMe) {
                        const isSuspicious = this.detectSuspiciousMessage(msg);
                        const userJid = msg.key.participant || msg.key.remoteJid;
                        
                        if (isSuspicious) {
                            colorful.warning(`🚨 Suspicious message detected from ${userJid}`);
                            
                            // Decrease trust score
                            await database.updateUserTrust(userJid, -15);
                            
                            // Check if should block
                            const isBlocked = await database.isUserBlocked(userJid);
                            if (isBlocked) {
                                try {
                                    await this.sock.updateBlockStatus(userJid, 'block');
                                    colorful.info(`🚫 Auto-blocked suspicious user: ${userJid}`);
                                    
                                    // Notify owner
                                    await this.sock.sendMessage(this.bot.ownerJid, {
                                        text: `🚨 *AUTO-BLOCKED SUSPICIOUS USER*\n\n👤 User: ${userJid}\n🛡️ Reason: Suspicious activity detected`
                                    });
                                } catch (error) {
                                    colorful.error(`Failed to block user: ${error.message}`);
                                }
                            }
                        }
                    }
                }
            }
        });
    }

    // ==================== AUTO-BLOCK FEATURE ====================
    async setupAutoBlock() {
        // This is handled in anti-bug feature
        //colorful.info('🔒 Auto-block integrated with anti-bug system');
    }

    // ==================== ANTI-DEMOTE PROTECTION ====================
    async setupAntiDemote() {
        this.sock.ev.on('group-participants.update', async (update) => {
            // Check if bot is being demoted
            if (update.action === 'demote' && update.participants.includes(this.sock.user.id)) {
                try {
                    colorful.warning(`🛡️ Bot demotion detected in ${update.id}`);
                    
                    // Notify owner
                    await this.sock.sendMessage(this.bot.ownerJid, {
                        text: `⚠️ *BOT DEMOTED*\n\n🏷️ Group: ${update.id}\n🔧 Action: Bot was demoted from admin`
                    });

                    // Auto-leave group if enabled
                    const groupSettings = await database.getGroupSettings(update.id);
                    if (groupSettings?.antidemote) {
                        await this.sock.groupLeave(update.id);
                        colorful.info(`🚪 Auto-left group after demotion: ${update.id}`);
                    }
                    
                } catch (error) {
                    colorful.error(`Anti-demote error: ${error.message}`);
                }
            }
        });
    }

    // ==================== MESSAGE CACHING ====================
    async cacheMessage(message) {
        if (message.key?.id) {
            this.deletedMessages.set(message.key.id, message);
            this.editedMessages.set(message.key.id, message);
            
            // Limit cache size to 1000 messages
            if (this.deletedMessages.size > 1000) {
                const firstKey = this.deletedMessages.keys().next().value;
                this.deletedMessages.delete(firstKey);
            }
            if (this.editedMessages.size > 1000) {
                const firstKey = this.editedMessages.keys().next().value;
                this.editedMessages.delete(firstKey);
            }
        }
    }

    // ==================== HELPER METHODS ====================
    extractMessageContent(message) {
        if (!message.message) return 'Unsupported message type';
        
        const messageType = Object.keys(message.message)[0];
        switch (messageType) {
            case 'conversation':
                return message.message.conversation;
            case 'extendedTextMessage':
                return message.message.extendedTextMessage.text;
            case 'imageMessage':
                return '[Image] ' + (message.message.imageMessage.caption || '');
            case 'videoMessage':
                return '[Video] ' + (message.message.videoMessage.caption || '');
            case 'audioMessage':
                return '[Audio Message]';
            case 'documentMessage':
                return `[Document] ${message.message.documentMessage.fileName || 'File'}`;
            case 'stickerMessage':
                return '[Sticker]';
            default:
                return `[${messageType}]`;
        }
    }

    async findRecentMessage(key) {
        // In a real implementation, you might want to maintain a recent messages cache
        // For now, return null and rely on the in-memory cache
        return null;
    }

    detectSuspiciousMessage(message) {
        const content = this.extractMessageContent(message).toLowerCase();
        
        // Suspicious patterns
        const suspiciousPatterns = [
            /http.*\.(exe|bin|scr|com|bat|vbs|js)/i,
            /script.*alert/i,
            /eval.*\(/i,
            /base64_decode/i,
            /javascript:/i,
            /onmouseover=/i,
            /onload=/i,
            /<script>/i,
            /document\.cookie/i,
            /window\.location/i,
            /phishing|scam|fraud/i,
            /bitcoin.*wallet/i,
            /password.*reset/i,
            /bank.*account/i
        ];

        // Check for suspicious links
        const urlRegex = /https?:\/\/[^\s]+/g;
        const urls = content.match(urlRegex);
        if (urls) {
            for (const url of urls) {
                if (url.includes('bit.ly') || url.includes('tinyurl') || url.includes('shorte.st')) {
                    return true;
                }
            }
        }

        // Check for suspicious patterns
        return suspiciousPatterns.some(pattern => pattern.test(content));
    }

    // ==================== INITIALIZE ALL FEATURES ====================
    async initializeAllFeatures() {
        try {
            
            
            await this.setupAntiDelete();
            await this.setupAntiEdit();
            await this.setupAutoViewStatus();
            await this.setupAutoReactStatus();
            await this.setupAutoTyping();
            await this.setupAutoRecording();
            await this.setupAntiBug();
            await this.setupAutoBlock();
            await this.setupAntiDemote();
            
            colorful.success('✅');
            
        } catch (error) {
            colorful.error(`❌ Failed to initialize features: ${error.message}`);
        }
    }

    // Method to cache messages from main message handler
    async processMessageForFeatures(message) {
        await this.cacheMessage(message);
        
        // Track user activity for trust scoring
        const userJid = message.key.participant || message.key.remoteJid;
        this.userActivity.set(userJid, Date.now());
    }
}

module.exports = Features;